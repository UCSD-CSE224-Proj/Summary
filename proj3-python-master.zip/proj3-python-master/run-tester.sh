#!/bin/bash

python3 src/tester.py $@
