#!/bin/bash

python3 src/server_try2.py $@
