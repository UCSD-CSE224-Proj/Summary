#include <sysexits.h>

#include <limits.h>
#include <stdlib.h>
#include <sys/sendfile.h>
#include <sys/stat.h>
#include <time.h>
#include <fstream>
#include <sstream>
#include <stack>
#include <iostream>            // input output
#include <string>            // for bzero
#include <sys/socket.h>     // creating socket
#include <netinet/in.h>        // for sockaddr_in
#include <unistd.h>            // for close
#include <sys/stat.h>
#include <fcntl.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <fstream>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include "HttpdServer.hpp"
#include "logger.hpp"

#include <pthread.h>
#include <sys/uio.h>
using namespace std;

using FileInfo = struct {
	int file_size;
	string last_modified_time;
};

FileInfo get_file_info(const char* path) {
	struct stat st;
	FileInfo info;
	if (stat(path, &st) == 0) {
		info.file_size = st.st_size;
		char t[100] = "";
		strftime(t, 100, "%a, %d %b %y %T %z", localtime(&st.st_mtime));
		info.last_modified_time = string(t);
	} else {
		info.file_size = -1;
		info.last_modified_time = "None";
	}
	return info;
}

char* my_strsep(char** stringp, const char* delim) {
    if (*stringp == NULL) return NULL;
    char* ret = *stringp;
    char* p = *stringp;
    int n = strlen(delim);
    while (*p != 0) {
        int i = 0;
        for (i = 0; i < n; i++) {
            if (p[i] == 0 || p[i] != delim[i]) break;
        }
        if (i == n) {
            *p = 0;
            *stringp = p + n;
            return ret;
        }
        p++;
    }
    if (*p == 0) *stringp = NULL;
    return ret;
}
char* my_split(char* request,string delim,char* request_piece, int &flag){
    auto log = logger();
    int dposfound;
    char* request_new;
    int dlenstr = strlen(request);
    log->info("request_my_split{}",request);
    delim="   ";
    if (dlenstr > 0)
    {
        log->info("dlenstr:{}",dlenstr);
        char *pfound = strstr(request, "\n\n"); //pointer to the first character found 's' in the string saux
        if (pfound != NULL)
        {
            dposfound = int (pfound - request); //saux is already pointing to the first string character 't'.
        }
        else{log->error("not find split");flag=-1;return NULL;}
        
        
    }
    else return NULL;
    strncpy(request_piece, request,dposfound+3);
    request_new=request+dposfound+4;

    return request_new;
}

string get_file_type(string& path, string& mime_file) {
    auto log = logger();
    
	string type("Unknown");
	if (path.find_last_of('.') != string::npos) {
		string suffix = path.substr(path.find_last_of('.'));
        log->info("suffix: {}", suffix);
		ifstream mime_type;
		mime_type.open(mime_file);
		if (mime_type.is_open()) {
            log->info("it is open");
			string line;
			string file_suf;
			string file_type;
			while (getline(mime_type, line)) {
				istringstream iss(line);
				iss >> file_suf;
				iss >> file_type;
                //log->info("the file_suf:{}",file_suf);
				if (strcmp(file_suf.c_str(),suffix.c_str())==0) {
					type = file_type;
					break;
				}
			}
		}
		mime_type.close();
	}
	return type;
}

string build_200_ok_header(string& path, string& mime_file) {
	string response;
	FileInfo info;
	response += "HTTP/1.1 200 OK\r\n";
	info = get_file_info(path.c_str());
	response += "Last-Modified: " + info.last_modified_time + "\r\n";
	response += "Content-Length: " + to_string(info.file_size) + "\r\n";
	response += "Content-Type: " + get_file_type(path, mime_file) + "\r\n";
	response += "\r\n";

	return response;
}

string build_400_header() {
	string response;
	response += "HTTP/1.1 400 Client Error\r\n";
	response += "\r\n";
	return response;
}

string build_404_header() {
	string response;
	response += "HTTP/1.1 404 Not Found\r\n";
	response += "\r\n";
	return response;
}

string build_close_header(){
    string header;
    header += "HTTP/1.1 200 OK\r\n";
    header += "Connection: close\r\n";
    header += "\r\n";
    return header;
}

FileStatus validate_file(string& full_path, char* url) {
    auto log = logger();
    if (url[0] != '/') {log->error("wrong path");return WRONG_PATH; } // path must start with '/'
    strsep(&url, "/");
	std::stack<char*> dir_stack;
	char* dir;
	while ((dir = strsep(&url, "/")) != NULL) {
		if (strcmp(dir, "..") == 0) {
			
			if (dir_stack.empty()) return ESCAPE_ROOT;
            dir_stack.pop();
		} else if (strcmp(dir, ".") == 0)
			;
		else
			dir_stack.push(dir);
	}

	if (*dir_stack.top() == 0) full_path += "index.html";
	char real_path[PATH_MAX];
	realpath(full_path.c_str(), real_path);
    //full_path="/Users/hangquan/Downloads/proj1-cse224-xh-master\ 3/sample_htdocs";
    log->info("full_path: {}",full_path.c_str());
    if (access(full_path.c_str(), F_OK) == -1){
        log->error("no file");
        return NO_FILE;
        
    }
		
	else {
        if (access(real_path, R_OK) == -1){
            log->error("no permission");
            return NO_PERMISSION;
        }
        
			
		else
			return OK;
	}
}



bool handle_request(string& request, int clnt_sock, HttpdServer* server) {
	auto log = logger();

	char* buf_copy = (char*)malloc(request.size()+1);
	strcpy(buf_copy, request.c_str());
    log->info("buffer_copy1:{}",buf_copy);
	string header;
    
	
    char* first_line = strsep(&buf_copy, "\r\n");
	strsep(&first_line, " ");
	char* url = strsep(&first_line, " ");
    char* protocal=strsep(&first_line, " ");
    if(strcmp(protocal,"HTTP/1.1")!=0){
        log->error("the Protocal is not right");
        header = build_400_header();
        send(clnt_sock, (void*)header.c_str(), (size_t)header.size(), 0);
        //free(buf_copy);
        return false;
    }
        
        
	char* key_value;
	bool have_host = false, should_close = false;
    log->info("buffer_copy3:{}",buf_copy);
	while ((key_value = strsep(&buf_copy, "\r\n")) != NULL) {
        
		char* key = strsep(&key_value, ":");
        log->info("key value{}",key);
		if (strcmp(key, "Host") == 0)
			have_host = true;
		else if (strcmp(key, "Connection") == 0) {
			strsep(&key_value, " ");
			char* value = strsep(&key_value, "\r\n");
			if (strcmp(value, "close") == 0) should_close = true;
		}
	}
    
	if (!have_host) {
        log->error("don't have host");
		header = build_400_header();
		send(clnt_sock, (void*)header.c_str(), (size_t)header.size(), 0);
		free(buf_copy);
		return false;
	} else if (should_close) {
        header=build_close_header();
		send(clnt_sock, (void*)header.c_str(), (size_t)header.size(), 0);
		free(buf_copy);
		return true;
	}

	string full_path = server->doc_root + url;
    //string full_path = server->doc_root;
    
	FileStatus status = validate_file(full_path, url);
    log->info("path status:{}",status==OK);
	if (status == OK) {
		log->info("file readable");
		log->info("full_path: {} 229", full_path);

		header = build_200_ok_header(full_path, server->mime_types);
		send(clnt_sock, (void*)header.c_str(), (size_t)header.size(), 0);

		int fd = open(full_path.c_str(), O_RDONLY);
		struct stat finfo;
		fstat(fd, &finfo);
		off_t off = 0;
        log->info("finfo.st_size {}",finfo.st_size);
        off_t len=finfo.st_size;
        log->info("len {}",len);
		int h = sendfile(clnt_sock,fd, &off,len);
        //int h=write(clnt_sock, fd, size_t nbyte);
		log->info("send {} bytes, status {}, errno {}", finfo.st_size, h,
				  errno);
		close(fd);
		free(buf_copy);
		return false;
	} else {
		switch (status) {
			case WRONG_PATH: {
				log->info("path not start with /");
				header = build_400_header();
				break;
			}
			case ESCAPE_ROOT: {
				log->info("path ecsape root dir");
				header = build_404_header();
				break;
			}
			case NO_FILE: {
				log->info("file not found");
				header = build_404_header();
				break;
			}
			case NO_PERMISSION: {
				log->info("no read permission");
				header = build_404_header();
				break;
			}
			default:
				break;
		}
	}
	send(clnt_sock, (void*)header.c_str(), (size_t)header.size(), 0);
	free(buf_copy);
	return false;
}

void HandleHttpRequest(int ClntSock, HttpdServer* server) {
	int recvMsgSize;
	auto log = logger();
	string request;
    string request_total;
    char* buf_copy;

   // char* request_piece=(char*)malloc(255);
    char*request_copy;
   // char* new_request;
    int flag=0;

	do {
		char* RecvBuffer = (char*)malloc(RECVBUFSIZE);
		char* buff_addr = RecvBuffer;
        recvMsgSize = read(ClntSock, RecvBuffer, RECVBUFSIZE - 1);
		if (recvMsgSize < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK){
                log->info("timeout, will close connection");    close(ClntSock);
                log->info("finsih transferring");return;
            }
				
            else{
                log->error("error getting message,why status: {}, errno: {}",
                               recvMsgSize, errno);
                    close(ClntSock);
                log->info("finsih transferring");
                return;
            }
				
        } else if (recvMsgSize == 0)  {free(buff_addr);break;}// sender closed tcp connection
			
		else {
			RecvBuffer[recvMsgSize] = 0;
            request_total+=RecvBuffer;
            free(buff_addr);
			log->info("reccived {} bytes:\n{}", recvMsgSize, RecvBuffer);
		}

	} while (recvMsgSize > 0);
    log->info("request_total{}",request_total);
    buf_copy = (char*)malloc(request_total.size()+1);
    strcpy(buf_copy, request_total.c_str());
    request_copy=buf_copy;
    log->info("request_copy{}",request_copy);
//    while(my_strsep())
    bool should_close = handle_request(request_total, ClntSock, server);
    
        request.clear();
        if (should_close) {
            log->info("shoule close");
           
            close(ClntSock);
            log->info("finsih transferring");
            return;
        }
	string headers=build_close_header();
         send(ClntSock, (void*) headers.c_str(), (ssize_t) headers.size(), 0);
	
//    while ((new_request=my_split(request_copy,"\r\n\r\n",request_piece,flag))!=NULL) {
//            request.append(request_piece);
//            request_copy=new_request;
//            log->info("handle request{}",request_piece);
//            memset(request_piece,0,255);
//
//          // find a double CRLF
//            //log->info("I do this{}",request_piece);
//            bool should_close = handle_request(request_piece, ClntSock, server);
//        log->info("here it is ");
//            request.clear();
//            if (should_close) {
//                log->info("shoule close");
//
//                goto Close;
//            }
//
//    }
    

}

HttpdServer::HttpdServer(INIReader& t_config)
	: config(t_config), thread_pool(new ThreadPool(5)) {
	auto log = logger();

	string pstr = config.Get("httpd", "port", "");
	if (pstr == "") {
		log->error("port was not in the config file");
		exit(EX_CONFIG);
	}
	port = pstr;

	string dr = config.Get("httpd", "doc_root", "");
	if (dr == "") {
		log->error("doc_root was not in the config file");
		exit(EX_CONFIG);
	}
	doc_root = dr;

	string mmtp = config.Get("httpd", "mime_types", "");
	if (mmtp == "") {
		log->error("mime_types was not in the config file");
		exit(EX_CONFIG);
	}
	mime_types = mmtp;
}

void HttpdServer::launch() {
	auto log = logger();

	log->info("Launching web server");
	log->info("Port: {}", port);
	log->info("doc_root: {}", doc_root);
	log->info("mime_types: {}", mime_types);



	// Put code here that actually launches your webserver...
	int ServSockfd, ClntSockfd;
	struct sockaddr_in ServAddr;
	struct sockaddr_in ClntAddr;
	unsigned short ServPort = atoi(port.c_str());
	unsigned int ClntLen;

	if ((ServSockfd = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) {
		log->error("can't create socket");
		exit(1);
	}

	memset(&ServAddr, 0, sizeof(ServAddr));
	ServAddr.sin_family = AF_INET;
	ServAddr.sin_addr.s_addr = htonl(INADDR_ANY);
	ServAddr.sin_port = htons(ServPort);

	if (::bind(ServSockfd, (struct sockaddr*)&ServAddr, sizeof(ServAddr)) == -1) {
		log->error("can't bind");
		exit(1);
	}
//MAXPENDING
	if (listen(ServSockfd, 1) == -1) {
		log->error("can't listen");
		exit(1);
	}

	while (1) {
		ClntLen = sizeof(ClntAddr);

		if ((ClntSockfd = accept(ServSockfd, (struct sockaddr*)&ClntAddr,
								 &ClntLen)) == -1) {  // set socket to non-block
			log->error("can't accept");
			close(ClntSockfd);
			exit(1);
		}
        
       struct timeval timeout={5,0};
       int ret1=setsockopt(ClntSockfd,SOL_SOCKET,SO_SNDTIMEO,(const char*)&timeout,sizeof(timeout));
       int ret2=setsockopt(ClntSockfd,SOL_SOCKET,SO_RCVTIMEO,(const char*)&timeout,sizeof(timeout));
	
		 string header=build_close_header();
         send(ClntSockfd, (void*) header.c_str(), (ssize_t) header.size(), 0);
       if (ret1 < 0&& ret2<0)
       { 		
	       string headers=build_close_header();
         send(ClntSockfd, (void*) headers.c_str(), (ssize_t) headers.size(), 0);
                   close(ClntSockfd);
	       		
                   log->info("connection close");
                   sleep(1);
               }
		HandleHttpRequest( ClntSockfd, this);
	
//         int retval;
//         retval = select(1, &ClntSockfd, NULL, NULL, &timeout);
// 	if(retval){
// 		log->info("time out");
		

// 	if(ClntSockfd)
//         close(ClntSockfd);
// 		sleep(1);
// 	}
		
	
	if(ClntSockfd)
        close(ClntSockfd);
        exit(1);
//		thread_pool->enqueue(HandleHttpRequest, ClntSockfd, this);
	}
}


///note:  I set /r/n/r/n to /r/n
// the recent problem is that we need to solve timeout, what that means
