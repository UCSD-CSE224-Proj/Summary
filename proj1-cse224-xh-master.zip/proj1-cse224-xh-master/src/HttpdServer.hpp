#ifndef HTTPDSERVER_HPP
#define HTTPDSERVER_HPP

#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <iostream>
#include <memory>
#include <string>
#include "ThreadPool.h"
#include "inih/INIReader.h"
#include "logger.hpp"

#define MAXPENDING 5
#define RECVBUFSIZE 1024

using namespace std;

enum FileStatus { WRONG_PATH, NO_FILE, NO_PERMISSION, ESCAPE_ROOT, OK };

class HttpdServer {
   public:
	HttpdServer(INIReader& t_config);

	void launch();

	friend void HandleHttpRequest(int ClntSock, HttpdServer* server);
	friend bool handle_request(string& request, int clnt_sock, HttpdServer* server);

   protected:
	INIReader& config;
	unique_ptr<ThreadPool> thread_pool;
	string port;
	string doc_root;
	string mime_types;
};
#endif  // HTTPDSERVER_HPP
