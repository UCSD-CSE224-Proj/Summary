#!/bin/bash

python3 src/client.py $@
