#!/bin/bash

python3 src/server.py $@
